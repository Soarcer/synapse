# Synapse

Monitor AI coding agents in real-time from the terminal. One command to start — works with Claude Code, Gemini CLI, and Codex CLI.

## Quick Start

Requires Node.js 20+. No install needed:

```bash
cd ~/your-project
npx @synapse-ai/cli start
```

This does three things:
1. Starts the Synapse server as a background daemon
2. Configures Claude Code hooks for the current project
3. Opens the dashboard in your browser

That's it. Every Claude Code session in this project now streams events to the dashboard.

## Commands

| Command | What it does |
|---------|-------------|
| `npx @synapse-ai/cli start` | Start server in foreground (Ctrl+C to stop) |
| `npx @synapse-ai/cli start -d` | Start as background daemon |
| `npx @synapse-ai/cli stop` | Stop the running server |
| `npx @synapse-ai/cli status` | Show URL, PID, and hook status |
| `npx @synapse-ai/cli open` | Open the dashboard in your browser |
| `npx @synapse-ai/cli hook` | Configure hooks for the current project |
| `npx @synapse-ai/cli unhook` | Remove hooks from the current project |
| `npx @synapse-ai/cli help` | Show usage info |

### Start options

```bash
npx @synapse-ai/cli start -d              # Background daemon (recommended)
npx @synapse-ai/cli start --port 9000     # Custom port
npx @synapse-ai/cli start --no-open       # Don't open browser
npx @synapse-ai/cli start --no-hook       # Don't configure hooks (server only)
npx @synapse-ai/cli start --observe-only  # Monitor only, no remote approval
```

## Multi-Project Setup

The server is global — start it once, then hook multiple projects:

```bash
npx @synapse-ai/cli start -d              # Start once
cd ~/project-a && npx @synapse-ai/cli hook   # Hook project A
cd ~/project-b && npx @synapse-ai/cli hook   # Hook project B
npx @synapse-ai/cli open                  # Dashboard shows all projects
```

## Remote Approval

When Claude Code requests permission (e.g., Bash, Edit), the request appears on the dashboard. Approve or deny from your browser — including your phone on the same network.

The `PermissionRequest` hook holds Claude's request open until you respond. All other hooks are async and never block Claude.

To disable remote approval, use `--observe-only` when starting or hooking.

## Troubleshooting

**Claude Code hangs on every prompt:**
The server is not running but hooks are configured. Run `npx @synapse-ai/cli start -d` or `npx @synapse-ai/cli unhook`.

**Events not appearing:**
Run `npx @synapse-ai/cli status` to check hook status. Re-run `npx @synapse-ai/cli hook` if needed.

**Port already in use:**
Use `npx @synapse-ai/cli start --port 9000` to pick a different port.

## License

MIT
