import { nanoid } from 'nanoid';
import { insertEvent, queryEvents, type EventRow } from '../db.js';
import type { Broadcaster } from './broadcaster.js';
import type { AgentEvent, AgentEventType } from '../../src/types/agent.js';

// ─── Hook Event Name → AgentEventType Mapping ──────────────────────

const HOOK_EVENT_MAP: Record<string, AgentEventType> = {
  SessionStart: 'session_start',
  SessionEnd: 'session_end',
  UserPromptSubmit: 'user_prompt',
  SubagentStart: 'agent_start',
  SubagentStop: 'agent_stop',
  PreToolUse: 'tool_start',
  PostToolUse: 'tool_end',
  PostToolUseFailure: 'tool_error',
  PermissionRequest: 'permission_request',
  Notification: 'notification',
  PreCompact: 'compact',
  Stop: 'stop',
};

const HOOK_EVENT_NAMES = new Set(Object.keys(HOOK_EVENT_MAP));

// ─── Normalize Raw Hook Payload ─────────────────────────────────────

export function normalizeHookPayload(raw: Record<string, unknown>): AgentEvent {
  const hookEventName = (raw.hook_event_name as string) || 'unknown';
  const eventType = HOOK_EVENT_MAP[hookEventName] || 'result';
  const now = Date.now();

  const event: AgentEvent = {
    id: nanoid(),
    type: eventType,
    sessionId: (raw.session_id as string) || 'unknown',
    timestamp: now,
    eventSource: 'hook',
  };

  // ── Common metadata (present on all hook events) ──
  if (raw.cwd) event.cwd = raw.cwd as string;
  if (raw.permission_mode) event.permissionMode = raw.permission_mode as string;
  if (raw.transcript_path) event.transcriptPath = raw.transcript_path as string;

  // ── Agent fields ──
  if (raw.agent_id) event.agentId = raw.agent_id as string;
  if (raw.agent_type) event.agentType = raw.agent_type as string;
  if (raw.agent_transcript_path) event.agentTranscriptPath = raw.agent_transcript_path as string;

  // ── Tool fields ──
  if (raw.tool_name) event.toolName = raw.tool_name as string;
  if (raw.tool_use_id) event.toolUseId = raw.tool_use_id as string;
  if (raw.tool_input && typeof raw.tool_input === 'object') {
    event.toolInput = raw.tool_input as Record<string, unknown>;
  }
  if (raw.tool_response && typeof raw.tool_response === 'object') {
    event.toolResponse = raw.tool_response as Record<string, unknown>;
  }

  // ── Event-specific fields ──
  switch (hookEventName) {
    case 'SessionStart':
      if (raw.model) event.model = raw.model as string;
      if (raw.source) event.source = raw.source as string;
      break;

    case 'SessionEnd':
      if (raw.reason) event.reason = raw.reason as string;
      break;

    case 'UserPromptSubmit':
      if (raw.prompt) event.text = raw.prompt as string;
      break;

    case 'Notification':
      if (raw.message) event.text = raw.message as string;
      if (raw.notification_type) event.notificationType = raw.notification_type as string;
      break;

    case 'PreCompact':
      if (raw.trigger) event.compactTrigger = raw.trigger as string;
      break;

    case 'PostToolUseFailure':
      if (raw.error) event.error = String(raw.error);
      break;
  }

  // ── Status mapping ──
  if (hookEventName === 'SubagentStart' || hookEventName === 'PreToolUse') {
    event.status = 'running';
  } else if (hookEventName === 'PostToolUse' || hookEventName === 'SubagentStop') {
    event.status = 'success';
  } else if (hookEventName === 'PostToolUseFailure') {
    event.status = 'error';
  }

  return event;
}

// ─── Store and Broadcast ────────────────────────────────────────────

export function storeAndBroadcast(
  raw: Record<string, unknown>,
  broadcaster: Broadcaster,
): AgentEvent {
  const event = normalizeHookPayload(raw);
  const hookEventName = (raw.hook_event_name as string) || 'unknown';

  // Persist to SQLite
  insertEvent({
    event_id: event.id,
    session_id: event.sessionId,
    hook_event_name: hookEventName,
    event_type: event.type,
    agent_id: event.agentId,
    agent_type: event.agentType,
    parent_agent_id: event.parentAgentId,
    tool_name: event.toolName,
    tool_use_id: event.toolUseId,
    tool_input: event.toolInput ? JSON.stringify(event.toolInput) : null,
    tool_response: event.toolResponse ? JSON.stringify(event.toolResponse) : null,
    status: event.status,
    error: event.error,
    token_input: event.tokenUsage?.input,
    token_output: event.tokenUsage?.output,
    duration_ms: event.duration,
    raw_payload: JSON.stringify(raw),
    created_at: event.timestamp,
  });

  // Broadcast to all WebSocket clients
  broadcaster.broadcast(event);

  return event;
}

// ─── Row → AgentEvent Conversion ────────────────────────────────────

export function rowToAgentEvent(row: EventRow): AgentEvent {
  const event: AgentEvent = {
    id: row.event_id,
    type: row.event_type as AgentEventType,
    sessionId: row.session_id,
    timestamp: row.created_at,
  };
  if (row.agent_id) event.agentId = row.agent_id;
  if (row.agent_type) event.agentType = row.agent_type;
  if (row.parent_agent_id) event.parentAgentId = row.parent_agent_id;
  if (row.tool_name) event.toolName = row.tool_name;
  if (row.tool_use_id) event.toolUseId = row.tool_use_id;
  if (row.tool_input) {
    try { event.toolInput = JSON.parse(row.tool_input); } catch { /* corrupted data */ }
  }
  if (row.tool_response) {
    try { event.toolResponse = JSON.parse(row.tool_response); } catch { /* corrupted data */ }
  }
  if (row.status) event.status = row.status as AgentEvent['status'];
  if (row.error) event.error = row.error;
  if (row.token_input != null && row.token_output != null) {
    event.tokenUsage = { input: row.token_input, output: row.token_output };
  }
  if (row.duration_ms != null) event.duration = row.duration_ms;

  // Infer event source from hook_event_name
  event.eventSource = HOOK_EVENT_NAMES.has(row.hook_event_name) ? 'hook' : 'sdk';

  // Restore rich metadata from raw_payload
  try {
    const raw = JSON.parse(row.raw_payload);
    if (raw.model) event.model = raw.model;
    if (raw.source) event.source = raw.source;
    if (raw.reason) event.reason = raw.reason;
    if (raw.cwd) event.cwd = raw.cwd;
    if (raw.permission_mode) event.permissionMode = raw.permission_mode;
    if (raw.prompt) event.text = raw.prompt;
    if (raw.message && event.type === 'notification') event.text = raw.message;
    if (raw.notification_type) event.notificationType = raw.notification_type;
    if (raw.trigger) event.compactTrigger = raw.trigger;
    if (raw.agent_transcript_path) event.agentTranscriptPath = raw.agent_transcript_path;
  } catch { /* ignore parse errors */ }

  return event;
}

// ─── Query Events (returns AgentEvent[]) ────────────────────────────

export function getStoredEvents(params: {
  sessionId?: string;
  agentId?: string;
  type?: string;
  limit?: number;
  offset?: number;
}): AgentEvent[] {
  const rows = queryEvents(params);
  return rows.map(rowToAgentEvent);
}
