#!/usr/bin/env node

// Claude Code hook script — reads JSON from stdin, POSTs to AgentViz server.
// No dependencies. Fire and forget (exit 0 regardless).
//
// Claude Code sends hook events as JSON on stdin with fields like:
//   session_id, hook_event_name, tool_name, tool_input, tool_response,
//   tool_use_id, agent_id, agent_type, cwd, transcript_path, etc.

const fs = require('fs');
const path = require('path');

const SERVER_URL = process.env.AGENTVIZ_URL || 'http://localhost:4000/api/events';
const DEBUG_LOG = path.join(__dirname, '..', 'hook_debug.log');

function debugLog(msg) {
  try {
    fs.appendFileSync(DEBUG_LOG, `[${new Date().toISOString()}] ${msg}\n`);
  } catch { /* ignore */ }
}

async function main() {
  debugLog('Hook invoked');
  try {
    const chunks = [];
    for await (const chunk of process.stdin) {
      chunks.push(chunk);
    }
    const body = Buffer.concat(chunks).toString('utf-8');
    debugLog(`Received body (${body.length} chars): ${body.slice(0, 200)}`);
    if (!body.trim()) {
      debugLog('Empty body, skipping');
      return;
    }

    // Validate JSON before sending
    JSON.parse(body);

    // POST with a 3-second timeout so we never block Claude Code
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3000);

    const resp = await fetch(SERVER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      signal: controller.signal,
    });

    debugLog(`POST response: ${resp.status} ${resp.statusText}`);
    clearTimeout(timer);
  } catch (err) {
    debugLog(`Error: ${err.message}`);
    // Fire and forget — never block Claude Code
  }
}

main().then(() => process.exit(0));
